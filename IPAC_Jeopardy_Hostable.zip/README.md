IPAC Jeopardy – Infection Prevention Challenge
=============================================

Ready-to-host static website. Includes all game files and audio.

How to host on GitHub Pages (quick):
1. Create a new GitHub repository (public or private).
2. Upload the contents of this folder to the repository root.
3. In the repository settings → Pages, set the Source to the `main` branch (or `gh-pages` branch) and root folder `/`.
4. Save; GitHub will provide a URL like `https://<your-user>.github.io/<repo-name>/` within a minute or two.

How to host on Netlify (very quick):
1. Go to https://app.netlify.com/ and sign in.
2. Click 'New site from Git' → connect your GitHub and pick the repository.
3. For a static site, accept the defaults and click 'Deploy site'.
4. Netlify will build and publish; you'll get a live URL immediately.

Local testing (on Android or desktop):
- Use a simple local server. From the folder, run:
    python3 -m http.server 8000
  Then open http://localhost:8000 in your browser or on your Android device (use your machine's IP address).

Notes:
- The site uses relative paths and is ready for static hosting.
- Audio autoplay may be blocked until the user interacts; that's expected browser behavior.
- Footer is neutral: "Designed for IPAC training".
