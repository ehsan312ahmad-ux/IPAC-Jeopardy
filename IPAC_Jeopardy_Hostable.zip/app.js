
const boardEl = document.getElementById('board');
const dialog = document.getElementById('dialog');
const dialogTitle = document.getElementById('dialog-title');
const dialogQuestion = document.getElementById('dialog-question');
const dialogAnswer = document.getElementById('dialog-answer');
const revealBtn = document.getElementById('reveal');
const backBtn = document.getElementById('back');
const closeBtn = document.getElementById('close');

const chime = document.getElementById('audio-chime');
const buzz = document.getElementById('audio-buzz');
const theme = document.getElementById('audio-theme');
const dd = document.getElementById('audio-dd');

let current = null;

function buildBoard(){
  const cats = Object.keys(QA);
  // header row: categories
  for (let c=0;c<cats.length;c++){
    const catDiv = document.createElement('div');
    catDiv.className = 'category';
    catDiv.innerText = cats[c];
    boardEl.appendChild(catDiv);
  }
  // tiles: 5 rows of points
  const points = [100,200,300,400,500];
  for (let r=0;r<points.length;r++){
    for (let c=0;c<cats.length;c++){
      const pt = points[r];
      const tile = document.createElement('div');
      tile.className = 'tile';
      tile.dataset.cat = cats[c];
      tile.dataset.point = pt;
      tile.innerText = pt;
      tile.addEventListener('click', onTileClick);
      boardEl.appendChild(tile);
    }
  }
}

function onTileClick(e){
  const tile = e.currentTarget;
  const cat = tile.dataset.cat;
  const pt = parseInt(tile.dataset.point);
  const qa = QA[cat][pt];
  current = {cat, pt, tile};
  dialogTitle.innerText = `${cat} — ${pt}`;
  dialogQuestion.innerText = qa[0];
  dialogAnswer.innerText = qa[1];
  dialogAnswer.classList.add('hidden');
  revealBtn.classList.remove('hidden');
  // play theme after user interaction
  try { theme.currentTime = 0; theme.play().catch(()=>{}); } catch(e){}
  dialog.classList.remove('hidden');
  // focus for accessibility
  revealBtn.focus();
}

revealBtn.addEventListener('click', ()=>{
  dialogAnswer.classList.remove('hidden');
  revealBtn.classList.add('hidden');
  try { chime.currentTime = 0; chime.play().catch(()=>{}); } catch(e){}
  // lock the tile
  if (current && current.tile){
    current.tile.classList.add('locked');
  }
});

backBtn.addEventListener('click', ()=>{
  dialog.classList.add('hidden');
  try { theme.currentTime = 0; theme.play().catch(()=>{}); } catch(e){}
  current = null;
});

closeBtn.addEventListener('click', ()=>{
  dialog.classList.add('hidden');
  current = null;
});

// keyboard accessibility
document.addEventListener('keydown', (e)=>{
  if (e.key === 'Escape') { dialog.classList.add('hidden'); current = null; }
});

// initialize
buildBoard();
